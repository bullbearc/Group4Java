import java.awt.*;
import javax.swing.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bullbearc
 */
class myGame extends JPanel{
    
	JButton jb99;
        String image_name = "homescreenimage";

	public myGame() {

		super();
		setBackground(Color.LIGHT_GRAY);
		setLayout(null);
                jb99 = new JButton("Return");
		jb99.setBounds(0, 0, 120, 25);
                add(jb99);
                jb99.setVisible(false);


		             
                //Customize 
                
                

	}
        @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image myImage = Toolkit.getDefaultToolkit().getImage("images/"+image_name+".jpg");
        g.drawImage(myImage, 0, 0, this);
    }
        
}
