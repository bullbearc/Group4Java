import java.awt.*;
import javax.swing.*;

public class myJFrame extends JFrame
{

    public myJFrame ()
    {
        super ("Group 4 Game");
        myJPanel mjp = new myJPanel();
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(mjp,"Center");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize (800, 480);
        setVisible(true);
   }
}