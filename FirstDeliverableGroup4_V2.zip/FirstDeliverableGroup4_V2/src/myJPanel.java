
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class myJPanel extends JPanel implements ActionListener{
        JButton jb1, jb2, jb3,jb90,jb99;
        
        myStart st1;//start
	myMap mp1;//map
        myHelp hp1;//help
        int img = 0;
    public myJPanel() {

        super();
        setLayout(null);
        setBackground(Color.lightGray);
        
        //Main menu buttons
        jb1 = new JButton("Start");//start st1
        jb1.setBackground(Color.white);
        jb2 = new JButton("Map Overview");//map mp1
        jb2.setBackground(Color.white);
        jb3 = new JButton("Help");//help hp1
        jb3.setBackground(Color.white);
        jb90 = new JButton("Exit");//exit
        jb90.setBackground(Color.white);
	
        add(jb1);
        add(jb2);
        add(jb3);
        add(jb90);
        jb1.setBounds(new Rectangle(0, 0, 160, 50));//start
        jb2.setBounds(new Rectangle(0, 50, 160, 50));//map overview
        jb3.setBounds(new Rectangle(0, 100, 160, 50));//help
        jb90.setBounds(new Rectangle(0, 150, 160, 50));//exit

        
        //Main menu Listeners
        jb1.addActionListener(this);
        jb2.addActionListener(this);
        jb3.addActionListener(this);
        jb90.addActionListener(this);


        //Add main panels and disable visibility to enable navigation
        //These are enabled in the actionlistener section
	st1 = new myStart();//start
        st1.setVisible(false);
        st1.setBounds(0, 0, 800, 480);
        add(st1);
	mp1 = new myMap();//map
        mp1.setVisible(false);
        mp1.setBounds(0, 0, 800, 480);
        add(mp1);
	hp1 = new myHelp();//help
        hp1.setVisible(false);
        hp1.setBounds(0, 0, 800, 480);
        add(hp1);
        ///return buttons
        st1.jb99.addActionListener(this);
        mp1.jb99.addActionListener(this);
        hp1.jb99.addActionListener(this);



        

       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
	Object obj = e.getSource();
        //////////////////Load New panels
	// start
	if (obj == jb1)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb90.setVisible(false);
            st1.setVisible(true);
            st1.jb99.setVisible(true);
            
	}
      
        //map
	if (obj == jb2)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb90.setVisible(false);
            mp1.setVisible(true);
            mp1.jb99.setVisible(true);
	}    
        //help
	if (obj == jb3)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb90.setVisible(false);
            hp1.setVisible(true);
            hp1.jb99.setVisible(true);
            
	}

        
        //////////////Return button
        //start
        if (obj == st1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb90.setVisible(true);
            st1.setVisible(false);
            st1.jb99.setVisible(false);
        }
        //map
        if (obj == mp1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb90.setVisible(true);
            mp1.setVisible(false);
            mp1.jb99.setVisible(false);
        }
        //help
        if (obj == hp1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb90.setVisible(true);
            hp1.setVisible(false);
            hp1.jb99.setVisible(false);
        }

        
        
        ///exit program
        if (obj == jb90) {
            System.exit(0);
        }
        
    }
     @Override
    public void paintComponent(Graphics g)  {
        super.paintComponent(g); 
    	Image myImage = Toolkit.getDefaultToolkit().getImage("images/homescreenimage.jpg");
    	g.drawImage(myImage, 0, 0, this);    	


    }
}

    