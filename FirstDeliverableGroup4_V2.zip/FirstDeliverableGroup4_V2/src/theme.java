
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bullbearc
 */
class theme extends JPanel implements ActionListener{

    JButton jbi0, jbi1, jbi2, jbi3,jb99;
    int image = 0;
    String image_name = "homescreenimage";

    public theme() {

        super();
        setBackground(Color.LIGHT_GRAY);
        setLayout(null);

        //Main menu buttons
        jbi0 = new JButton("Select Theme");
        jbi0.setBackground(Color.white);
        jbi1 = new JButton("Image 1");
        jbi1.setBackground(Color.white);
        jbi2 = new JButton("Image 2");
        jbi2.setBackground(Color.white);
        jbi3 = new JButton("Image 3");
        jbi3.setBackground(Color.white);
        jb99 = new JButton("Return");
	jb99.setBounds(0, 0, 120, 25);
        add(jb99);
        jb99.setVisible(false);
        
        //Add components
        add(jbi0);
        add(jbi1);
        add(jbi2);
        add(jbi3);
        
        //position components
        jbi0.setBounds(new Rectangle(0, 25, 160, 20));//Select Theme
        jbi1.setBounds(new Rectangle(0, 45, 160, 50));//Image 1
        jbi2.setBounds(new Rectangle(0, 95, 160, 50));//Image 2
        jbi3.setBounds(new Rectangle(0, 145, 160, 50));//Image 3
        
       // jbi1.addActionListener(this);
        //jbi2.addActionListener(this);
        //jbi3.addActionListener(this);
        


    }

 /*   @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image == 1)
	{
            Image myImage = Toolkit.getDefaultToolkit().getImage(
                    "images/image1.jpg");
            g.drawImage(myImage, 0, 0, this);
            
	}
	if (image == 2)
	{
            Image myImage2 = Toolkit.getDefaultToolkit().getImage(
                    "images/image2.jpg");
            g.drawImage(myImage2, 0, 0, this);
             
	}
	if (image == 3)
	{
            Image myImage3 = Toolkit.getDefaultToolkit().getImage(
                    "images/image3.jpg");
            g.drawImage(myImage3, 0, 0, this);
            
             
	}

    }
*/
        public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image myImage = Toolkit.getDefaultToolkit().getImage("images/"+image_name+".jpg");
        g.drawImage(myImage, 0, 0, this);
        
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();

        
    }
}
