import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bullbearc
 */
class myStart extends JPanel implements ActionListener{
        JButton jb1, jb2, jb3,jb4,jb99;
        myGame gm1;//start
	character ch1;//character
	theme th1;//theme
        howTo ht1;
     String image_name = "homescreenimage";

  public myStart() {

        super();
        setBackground(Color.LIGHT_GRAY);
        setLayout(null);
        jb99 = new JButton("Main Menu");
        jb99.setBounds(0, 0, 120, 25);
        add(jb99);
        jb99.setVisible(false);
        //Start Panel buttons
        jb1 = new JButton("New Game");//Newgame gm1
        jb1.setBackground(Color.white);
        jb2 = new JButton("Character Select");//character slect ch1
        jb2.setBackground(Color.white);
        jb3 = new JButton("Theme");//Theme th1
        jb3.setBackground(Color.white);
        jb4 = new JButton("How To Play");//how to ht1
        jb4.setBackground(Color.white);
        

	
        
        add(jb1);
        add(jb2);
        add(jb3);
        add(jb4);
        add(jb99);
        jb1.setBounds(new Rectangle(0, 25, 160, 50));//start
        jb2.setBounds(new Rectangle(0, 75, 160, 50));//map overview
        jb3.setBounds(new Rectangle(0, 125, 160, 50));//theme
        jb4.setBounds(new Rectangle(0, 175, 160, 50));//how to
        //Main menu Listeners
        jb1.addActionListener(this);
        jb2.addActionListener(this);
        jb3.addActionListener(this);
        jb4.addActionListener(this);
        //Add main panels and disable visibility to enable navigation
        //These are enabled in the actionlistener section
        //Start panels
        gm1 = new myGame();//start
        gm1.setVisible(false);
        gm1.setBounds(0, 0, 800, 480);
        add(gm1);
	ch1 = new character();//character
        ch1.setVisible(false);
        ch1.setBounds(0, 0, 800, 480);
        add(ch1);
	th1 = new theme();//theme
        th1.setVisible(false);
        th1.setBounds(0, 0, 800, 480);
        add(th1);
	ht1 = new howTo();//how to
        ht1.setVisible(false);
        ht1.setBounds(0, 0, 800, 480);
        add(ht1);
        ///return buttons
        //start return buttons
        gm1.jb99.addActionListener(this);
        ch1.jb99.addActionListener(this);
        th1.jb99.addActionListener(this);
        ht1.jb99.addActionListener(this);
        //theme listener
        th1.jbi1.addActionListener(this);
        th1.jbi2.addActionListener(this);
        th1.jbi3.addActionListener(this);
        

	}

    @Override
    public void actionPerformed(ActionEvent event) {
	Object obj = event.getSource();
        //////////////////Load New panels

        //Panels ontop of myStart
        // game
	if (obj == jb1)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb4.setVisible(false);
            jb99.setVisible(false);
            gm1.setVisible(true);
            gm1.jb99.setVisible(true);
            
	}
      
        //character
	if (obj == jb2)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb4.setVisible(false);
            jb99.setVisible(false);
            ch1.setVisible(true);
            ch1.jb99.setVisible(true);
	}    
        //theme
	if (obj == jb3)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb4.setVisible(false);
            jb99.setVisible(false);
            th1.setVisible(true);
            th1.jb99.setVisible(true);
            //repaint();

        }
        //how to
	if (obj == jb4)
	{
            jb1.setVisible(false);
            jb2.setVisible(false);
            jb3.setVisible(false);
            jb4.setVisible(false);
            jb99.setVisible(false);
            ht1.setVisible(true);
            ht1.jb99.setVisible(true);
           // repaint();
        }
        
        //////////////Return button

        //Panels on myStart
        //game
        if (obj == gm1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb4.setVisible(true);
            gm1.setVisible(false);
            //st1.setVisible(true);
            gm1.jb99.setVisible(false);
            jb99.setVisible(true);
            //repaint();
        }
        //character
        if (obj == ch1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb4.setVisible(true);
            ch1.setVisible(false);
            //st1.setVisible(true);
            ch1.jb99.setVisible(false);
            jb99.setVisible(true);
            //repaint();
        }
        //theme
        if (obj == th1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb4.setVisible(true);
            th1.setVisible(false);
            //st1.setVisible(true);
            th1.jb99.setVisible(false);
            jb99.setVisible(true);
            //repaint();
            
        }
        //how to
        if (obj == ht1.jb99)
        {
            jb1.setVisible(true);
            jb2.setVisible(true);
            jb3.setVisible(true);
            jb4.setVisible(true);
            ht1.setVisible(false);
            //st1.setVisible(true);
            ht1.jb99.setVisible(false);
            jb99.setVisible(true);
            //repaint();
        }
        
        ////Background listner
        if (obj == th1.jbi1)
        {
            //th1.image = 1;
            image_name="image1";
            gm1.image_name="image1";
            ch1.image_name="image1";
            th1.image_name="image1";
            ht1.image_name="image1";
            repaint();
            
        }
        if (obj == th1.jbi2)
        {
            //th1.image = 1;
            image_name="image2";
            gm1.image_name="image2";
            ch1.image_name="image2";
            th1.image_name="image2";
            ht1.image_name="image2";
            repaint();
        }
        if (obj == th1.jbi3)
        {
            //th1.image = 1;
            image_name="image3";
            gm1.image_name="image3";
            ch1.image_name="image3";
            th1.image_name="image3";
            ht1.image_name="image3";
            repaint();
        }
        
        
        
    }
    
        @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image myImage = Toolkit.getDefaultToolkit().getImage("images/"+image_name+".jpg");
        g.drawImage(myImage, 0, 0, this);
        
        
    }

}


